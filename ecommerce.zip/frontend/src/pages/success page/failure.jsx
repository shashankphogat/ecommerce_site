import React from 'react'

export const Failure = () => {
  return (
    <div>failure</div>
  )
}
