import React from 'react'

export const Success = () => {
  return (
    <div>success</div>
  )
}
